<?php

namespace App\Http\Controllers;

use App\Models\Servicio;
use Illuminate\Http\Request;

/**
 * Class ServicioController
 * @package App\Http\Controllers
 */

class ServicioController extends Controller
{
       /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $serv = Servicio::orderBy('servicios.costo', request('sorted', 'ASC'))->paginate(10); // Este es la forma correcta con Eloquent de Laravel

        return view('servicios.index', compact('serv'));
        //metodo para insertar 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   

        $servi = new Servicio();
        return view('servicios.create', compact('servi'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    // metodo para almacenar los regsitrso
    public function store(Request $request)
    {
       //request()->validate(servicios::$rules);

        /*$servi = servicios::create($request->all());
        $servi->save();
        return redirect()->route('servicios.index')
            ->with('success', 'Service created successfully.');*/
    
       // METODO FUNCIONAL DEL GUARDADO DE DATOS 
        $serv2 = new servicio();
        //$serv2->id = $request->id;
        $serv2->servicio = $request->servicio;
        $serv2->descripcion = $request->descripcion;
        $serv2->costo = $request->costo;
        $serv2->save();
        return redirect()->route('servicios.index')
            ->with('success', 'Service created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $servi = Servicio::find($id);

        return view('servicios.show', compact('servi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $servi = Servicio::find($id);

        return view('servicios.edit', compact('servi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Servicio $servicio
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       /* Servicios::findOrFail($id)->update($request->all());//ESTE ES CON ELOQUENT

        return redirect()->route('servicios.index');*/
        $servicio_update = Servicio::find($id);
        //$servicio_update->id = $request->input('id');
        $servicio_update->servicio = $request->input('servicio');
        $servicio_update->descripcion = $request->input('descripcion');
        $servicio_update->costo = $request->input('costo');
        $servicio_update->save();
        return redirect()->route('servicios.index');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $ser = Servicio::findOrFail($id)->delete();

        return redirect()->route('servicios.index');
    }
}
